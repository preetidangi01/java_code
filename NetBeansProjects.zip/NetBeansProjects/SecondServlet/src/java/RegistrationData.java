import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RegistrationData extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
//            out.print(request.getParameter("Name"));
//            out.print(request.getParameter("FName"));
//            out.print(request.getParameter("email"));
//            out.print(request.getParameter("password"));
//            out.print(request.getParameter("contact"));
//            out.print("szdlfnjkzfnjk");
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/javainfo", "root", "root");
                PreparedStatement ps = con.prepareStatement("insert into servlet(name,fname,email_id,password,mobile) values(?,?,?,?,?)");
                ps.setString(1, request.getParameter("Name"));
                ps.setString(2, request.getParameter("FName"));
                ps.setString(3, request.getParameter("email"));
                ps.setString(4, request.getParameter("password"));
                ps.setString(5, request.getParameter("contact"));
                int i = ps.executeUpdate();
                if (i > 0) {
                    response.sendRedirect(request.getContextPath()+"/Login");
                }
            } catch (ClassNotFoundException | SQLException e) {
                out.println("" + e);
            }

        }
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(RegistrationData.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(RegistrationData.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
