
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class Login extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.print("<!DOCTYPE html>\n"
                    + "\n"
                    + "<html>\n"
                    + "\n"
                    + "<head>\n"
                    + "    <title>TODO supply a title</title>\n"
                    + "    <meta charset=\"UTF-8\">\n"
                    + "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
                    + "    <style>\n"
                    + "        #first {\n"
                    + "            /* background-color: gray; */\n"
                    + "            height: 500px;\n"
                    + "            width: 100%;\n"
                    + "            display: flex;\n"
                    + "            flex-direction: column;\n"
                    + "            align-items: center;\n"
                    + "            justify-content: center;\n"
                    + "        }\n"
                    + "        #first form\n"
                    + "        {\n"
                    + "           \n"
                    + "            background-color: cadetblue;\n"
                    + "            display: flex;\n"
                    + "            flex-direction: column;\n"
                    + "            align-items: center;\n"
                    + "            border: 2px solid;\n"
                    + "            justify-content: center;\n"
                    + "            height: 400px;\n"
                    + "            border-radius: 10px;\n"
                    + "            width: 30%;\n"
                    + "        }\n"
                    + "        form span {\n"
                    + "            background-color: aliceblue;\n"
                    + "            height: 30px;\n"
                    + "            /* border: 1px solid; */\n"
                    + "            display: flex;\n"
                    + "            align-items: center;\n"
                    + "            justify-content: center;\n"
                    + "            width: 100%;\n"
                    + "        }\n"
                    + "        form span input{\n"
                    + "            /* background-color: aliceblue; */\n"
                    + "            margin-top: 10px;\n"
                    + "            height: 30px;\n"
                    + "            /* border: 1px solid; */\n"
                    + "            width: 80%;\n"
                    + "        }\n"
                    + "    </style>\n"
                    + "</head>\n"
                    + "\n"
                    + "<body>\n"
                    + "    <div id=\"first\">\n"
                    + "        <form action='LoginData'>\n"
                    + "\n"
                    + "            <span> User Id</span>\n"
                    + "            <span><input type=\"text\" name='Name' required></span>\n"
                    + "\n"
                    + "\n"
                    + "            <span>Password</span>\n"
                    + "            <span><input type=\"text\" name='password' required></span>\n"
                    + "\n"
                    + "\n"
                    + "            <span><input type=\"submit\" name=\"login\" value=\"login\"></span>\n"
                    + "            <span> <a href=\"Registration.html\">New user</a></span>\n"
                    + "\n"
                    + "\n"
                    + "</body>\n"
                    + "\n"
                    + "</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
