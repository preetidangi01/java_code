/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.frame;

/**
 *
 * @author PILR
 */
public class Frame {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
